@echo off
title KHOJ
echo Starting KHOJ...
start msedge --app="https://anuragpbusiness-stack.github.io/khoj/" 2>nul || start chrome --app="https://anuragpbusiness-stack.github.io/khoj/" 2>nul || start "" "https://anuragpbusiness-stack.github.io/khoj/"
