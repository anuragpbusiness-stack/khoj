✦ KHOJ — JOURNAL OF CULTURE, DISCOURSE & ATOMIC IDEAS ✦
======================================================
Minimal Dark Edition

FOR WINDOWS:
------------
Option 1 (Instant Desktop Icon):
  Double-click "Install-KHOJ-Windows-Desktop-Icon.bat".
  This creates a "KHOJ" desktop app icon on your desktop and launches the app!

Option 2 (Direct Launch):
  Double-click "KHOJ - Windows Launcher.bat".

FOR MACBOOK (macOS):
-------------------
Option 1 (Native Mac App):
  Double-click "KHOJ.app" or drag it into your "Applications" folder or Dock.

Option 2 (Terminal Command):
  Double-click "KHOJ - Mac Launcher.command".

OFFLINE USAGE:
--------------
Double-click "index.html" to run KHOJ directly in any browser with full local storage.
