@echo off
set SCRIPT="%TEMP%\khoj_shortcut.vbs"
echo Set oWS = WScript.CreateObject("WScript.Shell") > %SCRIPT%
echo sLinkFile = oWS.SpecialFolders("Desktop") ^& "\KHOJ.lnk" >> %SCRIPT%
echo Set oLink = oWS.CreateShortcut(sLinkFile) >> %SCRIPT%
echo oLink.TargetPath = "msedge.exe" >> %SCRIPT%
echo oLink.Arguments = "--app=""https://anuragpbusiness-stack.github.io/khoj/""" >> %SCRIPT%
echo oLink.Description = "KHOJ - Minimal Dark Editorial Culture & Ideas" >> %SCRIPT%
echo oLink.Save >> %SCRIPT%
cscript /nologo %SCRIPT%
del %SCRIPT% 2>nul
echo [OK] KHOJ desktop icon created successfully!
start "" "%USERPROFILE%\Desktop\KHOJ.lnk"
