#!/bin/bash
cd "$(dirname "$0")"
if [ -d "/Applications/Google Chrome.app" ]; then
    open -na "Google Chrome" --args --app="https://anuragpbusiness-stack.github.io/khoj/"
elif [ -d "/Applications/Microsoft Edge.app" ]; then
    open -na "Microsoft Edge" --args --app="https://anuragpbusiness-stack.github.io/khoj/"
else
    open -a "Safari" "https://anuragpbusiness-stack.github.io/khoj/"
fi
